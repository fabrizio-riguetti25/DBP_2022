var l=localStorage;

email_reg.addEventListener("focusout", function(){
    l.setItem("email", email_reg.value)
})
pswr_reg.addEventListener("focusout", function(){
    l.setItem("pswr", pswr_reg.value)
})
nombre.addEventListener("focusout", function(){
    l.setItem("nombre", nombre.value)
})
apellidos.addEventListener("focusout", function(){
    l.setItem("apellidos", apellidos.value)
})
dni.addEventListener("focusout", function(){
    l.setItem("dni", dni.value)
})
presentacion.addEventListener("focusout", function(){
    l.setItem("presentacion", presentacion.value)
})
nmr.addEventListener("focusout", function(){
    l.setItem("nmr", nmr.value)
})
cod_pos.addEventListener("focusout", function(){
    l.setItem("cod_pos", cod_pos.value)
})
fb.addEventListener("focusout", function(){
    l.setItem("fb", fb.value)
})
ig.addEventListener("focusout", function(){
    l.setItem("ig", ig.value)
})
twt.addEventListener("focusout", function(){
    l.setItem("twt", twt.value)
})
skill1.addEventListener("focusout", function(){
    l.setItem("skill1", skill1.value)
})
skill2.addEventListener("focusout", function(){
    l.setItem("skill2", skill2.value)
})
skill3.addEventListener("focusout", function(){
    l.setItem("skill3", skill3.value)
})
skill4.addEventListener("focusout", function(){
    l.setItem("skill4", skill4.value)
})
skill5.addEventListener("focusout", function(){
    l.setItem("skill5", skill5.value)
})
work1.addEventListener("focusout", function(){
    l.setItem("work1", work1.value)
})
work2.addEventListener("focusout", function(){
    l.setItem("work2", work2.value)
})
work3.addEventListener("focusout", function(){
    l.setItem("work3", work3.value)
})
workexp1_1.addEventListener("focusout", function(){
    l.setItem("workexp1_1", workexp1_1.value)
})
workexp1_2.addEventListener("focusout", function(){
    l.setItem("workexp1_2", workexp1_2.value)
})
workexp1_3.addEventListener("focusout", function(){
    l.setItem("workexp1_3", workexp1_3.value)
})
workexp2_1.addEventListener("focusout", function(){
    l.setItem("workexp2_1", workexp2_1.value)
})
workexp2_2.addEventListener("focusout", function(){
    l.setItem("workexp2_2", workexp2_2.value)
})
workexp2_3.addEventListener("focusout", function(){
    l.setItem("workexp2_3", workexp2_3.value)
})
workexp3_1.addEventListener("focusout", function(){
    l.setItem("workexp3_1", workexp3_1.value)
})
workexp3_2.addEventListener("focusout", function(){
    l.setItem("workexp3_2", workexp3_2.value)
})
workexp3_3.addEventListener("focusout", function(){
    l.setItem("workexp3_3", workexp3_3.value)
})
sec.addEventListener("focusout", function(){
    l.setItem("sec", sec.value)
})
sup.addEventListener("focusout", function(){
    l.setItem("sup", sup.value)
})
mstr.addEventListener("focusout", function(){
    l.setItem("mstr", mstr.value)
})
doc.addEventListener("focusout", function(){
    l.setItem("doc", doc.value)
})
hobbie1.addEventListener("focusout", function(){
    l.setItem("hobbie1", hobbie1.value)
})
hobbie2.addEventListener("focusout", function(){
    l.setItem("hobbie2", hobbie2.value)
})
hobbie3.addEventListener("focusout", function(){
    l.setItem("hobbie3", hobbie3.value)
})
hobbie4.addEventListener("focusout", function(){
    l.setItem("hobbie4", hobbie4.value)
})